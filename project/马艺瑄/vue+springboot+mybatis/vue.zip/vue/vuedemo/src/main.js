/**
 * Created by gubaoer on 17/4/18.
 */

import Vue from 'vue'
import {
    Button,
    Select,
    Row,
    Col,
    Pagination,
    Table,
    TableColumn,
    Form,
    FormItem,
    Input,
    Dialog,
    Option
} from 'element-ui'
import App from './App.vue'
//Element-UI使用指南 Element-UI是饿了么前端团队
//推出的一款基于Vue.js 2.0 的桌面端UI框架,
//手机端有对应框架是 Mint UI 
import 'E:/Study/Practice/vue/vuedemo/node_modules/element-ui/lib/theme-chalk/index.css'
import lang from 'element-ui/lib/locale/lang/en'
import locale from 'element-ui/lib/locale'

// 导入更多的第三方库的组件
//Moment.js 是一个 JavaScript 日期处理类库
//,用于解析、检验、操作、以及显示日期
import moment from 'moment'
//Vue2.0的网络请求库
import axios from 'axios'
Vue.prototype.$ajax = axios
Vue.config.productionTip = false
//curvejs 中文读["克js"],是腾讯AlloyTeam
//打造的一款魔幻线条框架,
//让线条成为一名优秀的舞者,
//让线条们成为优秀的舞团,HTML5 Canvas就是舞台。
import curvejs from 'curvejs'

//Object.defineProperty 是vue中双向绑定的基础。
//vue是通过数据劫持的方式来做数据绑定的，
//最核心的方法是通过 Object.defineProperty()
//方法来实现对属性的劫持，达到能监听到数据的变动。
Object.defineProperty(Vue.prototype, '$moment', { value: moment });
Object.defineProperty(Vue.prototype, '$axios', { value: axios });
Object.defineProperty(Vue.prototype, '$curvejs', { value: curvejs });

//引入Element-UI组件的步骤
Vue.use(Button);
Vue.use(Select);
Vue.use(Row);
Vue.use(Col);
Vue.use(Pagination);
Vue.use(Table);
Vue.use(TableColumn);
Vue.use(Form);
Vue.use(FormItem);
Vue.use(Input);
Vue.use(Dialog);
Vue.use(Option);

locale.use(lang);



// eslint-disable-next-line no-new
new Vue({
    el: '#app',
    render: h => h(App)
});

