<template>
<ul>
    <li class="el-menu-item is-active" style="">{{msg}}</li>
    <li class="el-menu-item is-active" style="">{{msg2}}</li>
    <li class="el-menu-item is-active" style="">{{msg3}}</li>
</ul>
</template>

<script>
    export default {
        name: 'db-sidebar',
        data() {
            return {
                msg: '接口测试',
                msg2:'历史记录',
                msg3:'编辑接口搜索'
            }
        }
    }
</script>

<style>
    li {
        padding-left: 20px;
    }
</style>

