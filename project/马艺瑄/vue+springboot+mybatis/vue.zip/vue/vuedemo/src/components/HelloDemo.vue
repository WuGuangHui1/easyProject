<template>
    <div class="hello">
        <h1>{{msg}}</h1>
    </div>
</template>

<script>
export default {
    name:'HelloDemo',
    data(){
        return{
            msg:'Hello world'
        }
    }
}
</script>
<style scoped>
h1{
    font-weight: normal;
}
</style>