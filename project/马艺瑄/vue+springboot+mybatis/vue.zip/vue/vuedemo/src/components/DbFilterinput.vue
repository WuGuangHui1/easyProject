<template>
    <el-form :inline="true" :model="formInline">
        <span>请求方法：</span>
        <el-select v-model="formInline.method" style="width:150px">
            <el-option value="get">Get</el-option>
            <el-option value="post">Post</el-option>
        </el-select>
        <el-input  id="link" v-model="formInline.link" style="width:700px"></el-input>  
        <el-button v-on:click="change">Send</el-button>  
        <div id="re">
            <input class="re" v-model="formInline.request">
            <div class="re">{{formInline.response}}</div>
        </div>
        
        
    </el-form>
</template>

<script>
    import lodash from 'lodash'
    import Bus from '../eventBus'
    export default {
        name: 'db-filterinput',
        data() {
            return {
                formInline: {
                    method:'选择方法',
                    link:'请输入请求链接',
                    request:'请输入请求参数',
                    response:null
                }
            }
        },
        methods: {
            change:function(){
                if(this.formInline.method==='get'){
                    this.send();
                }else{
                    this.send1();
                }
            },
            send: function () {
                    this.$axios.get(this.formInline.link)
                        .then((res) => {
                            this.formInline.response = res.data;
                            console.log(res.data);
                        }).catch(function (res) {
                        console.log(res)
                    });
            },
            send1: function () {
                this.$axios.post(this.formInline.link,{ 	phoneArea: "86", 	phoneNumber: "20000000000", 	password: "netease123" })
                    .then((res) => {
                            this.formInline.response = res.data;
                            console.log(res.data);
                        }).catch(function (res) {
                        console.log(res)
                    });
            }
        }
    }
</script>

<style scoped>
#re{
    margin-top: 20px;
}
.re{
    width:1000px;
    height: 200px;
    margin-bottom:20px;
    border-radius: 4px;
    border: 1px solid #DCDFE6;
}
.re:focus{
    border-style:solid;
    border-color: #03a9f4;
}
</style>