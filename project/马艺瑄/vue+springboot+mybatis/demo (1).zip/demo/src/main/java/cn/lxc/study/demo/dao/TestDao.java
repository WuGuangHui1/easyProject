package cn.lxc.study.demo.dao;


import cn.lxc.study.demo.entity.TestEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface TestDao {

    TestEntity getById(Integer id);

}